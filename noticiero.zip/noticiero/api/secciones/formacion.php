<?php
/*****
SUSTITUYE LAS XXX POR UN VALOR DE UNA NOTICIA DE INTERES EN ESTA CATEGORIA
*****/

$formacion = [
"titulo" => "XXX",
"autor" => "Gabinete de comunicación",
"resumen" => "XXX",
];
?>