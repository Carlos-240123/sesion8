<?php
/*****
SUSTITUYE LAS XXX POR UN VALOR DE UNA NOTICIA DE INTERES EN ESTA CATEGORIA
*****/

$portada = [
"titulo" => "Portada",
"autor" => "jperez",
"resumen" => "Las noticias mas importantes del 2025",
];
?>
