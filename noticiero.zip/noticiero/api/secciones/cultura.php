<?php
/*****
SUSTITUYE LAS XXX POR UN VALOR DE UNA NOTICIA DE INTERES EN ESTA CATEGORIA
*****/

$cultura = [
"titulo" => "XXX",
"autor" => "XXX",
"resumen" => "XXX",
];
?>
